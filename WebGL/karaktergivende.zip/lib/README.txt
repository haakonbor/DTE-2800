Credits:

//From: https://sites.google.com/site/webglbook/home/downloads
cuon-matrix.js
cuon-utils.js

//From: http://glmatrix.net/
gl-matrix.js
gl-matrix-min.js

//From: http://sylvester.jcoglan.com/
sylvester.src.js

//From: http://github.com/mrdoob/three.js
three.min.js

//From: https://www.khronos.org/registry/webgl/sdk/debug/webgl-debug.js	
webgl-debug.js

//From: https://github.com/KhronosGroup/WebGL/blob/master/sdk/demos/common/webgl-utils.js
webgl-utils.js
