import {
  Uniform
} from '../../../src/Three';

export const TechnicolorShader: {
  uniforms: {
    tDiffuse: Uniform;
  };
  vertexShader: string;
  fragmentShader: string;
};
